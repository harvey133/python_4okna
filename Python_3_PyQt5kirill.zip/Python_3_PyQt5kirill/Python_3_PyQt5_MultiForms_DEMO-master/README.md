# Python_3_PyQt5_MultiForms_DEMO
Многооконная программа с компонентами выбора и списками в Python3 с PyQt5

![Screenshot](Python-08-1.png)

![Screenshot](Python-08-2.png)

![Screenshot](Python-08-3.png)

![Screenshot](Python-08-4.png)

![Screenshot](Python-08-5.png)
